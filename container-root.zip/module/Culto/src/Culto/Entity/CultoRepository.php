<?php
namespace Culto\Entity;

use Doctrine\ORM\EntityRepository;

class CultoRepository extends EntityRepository{

}